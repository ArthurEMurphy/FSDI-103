//this is a comment in JS
//this is JS zone
//alert("Hello world");
//prompt("Enter your name");
console.log("Hello world");
console.warn("This is a warning");
console.error("Fatal Error ... buy another computer");

var user; // initialization
user="Arthur"; //value assignation


var age=99;

let studentName="Astrid";
const taxes=0.08;
console.log(100*taxes);

document.write(`<h6>Hello ${studentName}</h6>`);
