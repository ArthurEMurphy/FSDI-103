let numberChildren=2
let jobTitle="Consultant";
let partnerName="Shauna";
let geoLocation="Cincinnati";
let example="example";
document.write(`You will be a ${jobTitle} in ${geoLocation} and married to ${partnerName} with ${numberChildren} kids.`);




let userName="Arthur";
let email="no@email.ca";
let password="123Password";
let age="40";
let country="Canada";
let salary="5000.00"
document.write(`${userName}, ${email}, ${password}, ${age}, ${country}, $${salary} (Annual).`)




document.write(`${userName}   ${email}   $${salary} (Annual)`);
