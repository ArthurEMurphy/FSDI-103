let userName="Arthur";
let userEmail="no@email.ca";
let password="123Password";
let age="40";
let country="USA";
let monthlySalary=2000.00
let yearlySalary=monthlySalary*12;
const taxes=0.08;

document.write(`
<div class="student">
    <p><b>Name:</b> ${userName}</p>
    <p><b>Email:</b> ${userEmail}</p>
    <p><b>Salary:</b> ${yearlySalary}</p>
</div>
`);