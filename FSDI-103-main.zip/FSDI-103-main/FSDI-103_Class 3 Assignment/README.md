# 3rdclassJS Cohort 28
This is an example of a simple calculator for FSDI class
