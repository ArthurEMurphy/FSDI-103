// function expression
// function addNumbers(a,b) {
//     return a + b;
// }

// function greet(name){
//     return "Hello " + name + "!";
// }
// console.log(greet("Art"));

// function declaration / anonymous
// let greet = function(name)
// {
//     return "Hello " + name + "!";
// }

// console.log(greet("Art"));

// function displayName(studentName){
//     document.write(`
//         <h2>Student List</h2>
//         <p>Student name: ${studentName}</p><hr>`)
// }

function multiplyByThree(num1){
    return num1 * 3;
}

console.log(multiplyByThree(8));

